import csv, sys
from pathlib import Path
from app.ingestion import parse_retail_csv
p=Path(sys.argv[1])
rows=parse_retail_csv(p.read_text(encoding="utf-8-sig"), source_slug="partner_csv")
print(f"Принято строк на проверку: {len(rows)}")
for r in rows[:10]: print(r["name"], r["price_rub"], r["quantity"], r["unit"], r["status"])
