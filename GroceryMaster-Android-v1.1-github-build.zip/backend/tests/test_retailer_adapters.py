from app.retailer_adapters import parse_jsonld_products, validate_retailer_url


def test_parse_product_jsonld_offer():
    html = '''<script type="application/ld+json">{
      "@context":"https://schema.org", "@type":"Product", "name":"Молоко 2.5%",
      "gtin13":"4601234567890", "brand":{"@type":"Brand","name":"Тест"},
      "offers":{"@type":"Offer","price":"89.90","priceCurrency":"RUB","url":"https://magnit.ru/p/1"}
    }</script>'''
    rows = parse_jsonld_products(html)
    assert len(rows) == 1
    assert rows[0]["name"] == "Молоко 2.5%"
    assert rows[0]["price_rub"] == "89.90"
    assert rows[0]["barcode"] == "4601234567890"


def test_reject_non_rub_and_malformed_jsonld():
    html = '''<script type="application/ld+json">{bad json}</script>
    <script type="application/ld+json">{"@type":"Product","name":"X","offers":{"price":"1","priceCurrency":"USD"}}</script>'''
    assert parse_jsonld_products(html) == []


def test_url_allowlist():
    assert validate_retailer_url("magnit", "https://magnit.ru/catalog")
    assert not validate_retailer_url("magnit", "https://evil.example/catalog")
    assert not validate_retailer_url("magnit", "http://magnit.ru/catalog")


def test_jsonld_url_requires_official_host_and_https():
    assert not validate_retailer_url("pyaterochka", "https://magnit.ru/catalog")
    assert not validate_retailer_url("lenta", "http://lenta.com/catalog")
    assert validate_retailer_url("spar", "https://myspar.ru/catalog")
