from app.retailer_integrations import public_network_status
from app.ingestion import normalize_off_product

def test_network_registry_is_broad_and_does_not_fake_live_feeds():
    rows = public_network_status()
    assert len(rows) >= 23
    assert all(row["automated_price_sync"] is False for row in rows)

def test_off_metadata_never_becomes_a_price():
    out = normalize_off_product({"status":1,"product":{"code":"3017620422003","product_name":"Chocolate","brands":"Brand","quantity":"100 g"}})
    assert out["name"] == "Chocolate"
    assert out["price_rub"] is None
    assert out["price_source"] is None
