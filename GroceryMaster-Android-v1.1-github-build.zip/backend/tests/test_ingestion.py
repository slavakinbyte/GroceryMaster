from app.ingestion import parse_retail_csv,product_metadata_from_off
def test_csv_import_is_review_only():
    csv="store_external_id,barcode,name,brand,quantity,unit,price_rub,observed_at,source_url\\ns1,3017620422003,Chocolate,X,100,g,99.90,2026-11-25T10:00:00+03:00,https://example.test/item"
    rows=parse_retail_csv(csv,"partner_test")
    assert len(rows)==1 and rows[0]["status"]=="requires_review"
def test_off_is_metadata_not_price():
    assert product_metadata_from_off({"status":1,"product":{"product_name":"Milk","code":"123"}})["name"]=="Milk"
