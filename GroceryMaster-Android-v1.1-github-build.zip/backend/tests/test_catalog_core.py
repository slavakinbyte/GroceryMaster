from decimal import Decimal
from app.catalog_core import normalize_unit,to_base_quantity,unit_price,valid_gtin
def test_units():
    assert normalize_unit("кг")=="kg"
    assert to_base_quantity("1.5","л")== (Decimal("1500.0"),"ml")
def test_unit_price_same_comparable_basis():
    assert unit_price("100","1","кг")== (Decimal("100.0000"),"RUB/kg")
    assert unit_price("50","500","г")== (Decimal("100.0000"),"RUB/kg")
def test_gtin():
    assert valid_gtin("3017620422003")
    assert not valid_gtin("3017620422004")
