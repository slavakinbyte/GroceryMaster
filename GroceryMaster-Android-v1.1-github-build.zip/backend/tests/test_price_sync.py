from app.price_sync import _normalize_record, _extract_rows


def test_normalize_partner_price_row():
    row = _normalize_record({"title": "Молоко", "price": "89,90", "unit": "1 л", "sku": "A1"},
                            "test-network", "Тестовая сеть", "2026-11-25T00:00:00+00:00")
    assert row["name"] == "Молоко"
    assert row["price_rub"] == "89.90"
    assert row["status"] == "requires_review"


def test_reject_invalid_price():
    assert _normalize_record({"name": "Молоко", "price": "0"}, "x", "X", "now") is None


def test_extract_json_and_csv_rows():
    assert _extract_rows({"products": [{"name": "A"}]}, "json") == [{"name": "A"}]
    assert _extract_rows("name,price\nA,10\n", "csv")[0]["price"] == "10"
