import csv, hashlib, io, json
from datetime import datetime
from decimal import Decimal, InvalidOperation
from .catalog_core import valid_gtin
def parse_retail_csv(content,source_slug):
    rows=[]
    content = content.replace("\\n", "\n")
    for row in csv.DictReader(io.StringIO(content)):
        try:
            price=Decimal(row["price_rub"].replace(",","."))
            qty=Decimal(row["quantity"].replace(",","."))
            observed=datetime.fromisoformat(row["observed_at"].replace("Z","+00:00"))
        except (InvalidOperation,ValueError,KeyError,AttributeError):
            continue
        if price<=0 or qty<=0 or not row.get("name"): continue
        barcode=(row.get("barcode") or "").strip() or None
        if barcode and not valid_gtin(barcode): barcode=None
        rows.append({**row,"price_rub":str(price),"quantity":str(qty),"barcode":barcode,"source_slug":source_slug,"observed_at":observed.isoformat(),"status":"requires_review"})
    return rows
def payload_hash(payload):
    return hashlib.sha256(json.dumps(payload,sort_keys=True,ensure_ascii=False,default=str).encode()).hexdigest()
def openfoodfacts_product_url(barcode):
    if not valid_gtin(barcode): raise ValueError("Invalid GTIN check digit")
    return f"https://world.openfoodfacts.org/api/v3/product/{barcode}.json"
def product_metadata_from_off(payload):
    if payload.get("status")!=1: return None
    p=payload.get("product") or {}
    return {"barcode":p.get("code"),"name":p.get("product_name"),"brand":p.get("brands"),"quantity_text":p.get("quantity"),"categories":p.get("categories_tags",[]),"ingredients":p.get("ingredients_text"),"source":"open_food_facts","requires_quality_review":True}

def normalize_off_product(payload):
    """Normalize Open Food Facts metadata. This must never create a price offer."""
    meta = product_metadata_from_off(payload)
    if not meta:
        return None
    return {
        "barcode": meta.get("barcode"), "name": meta.get("name"),
        "brand": meta.get("brand"), "quantity_text": meta.get("quantity_text"),
        "categories": meta.get("categories", []),
        "ingredients": meta.get("ingredients"),
        "metadata_source": "open_food_facts",
        "metadata_requires_review": True,
        "price_rub": None,
        "price_source": None
    }
