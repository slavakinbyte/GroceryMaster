"""Safe adapters for retailer-authorized feeds and public JSON-LD catalog pages.

This module does not bypass authentication, bot checks, CAPTCHAs, or access controls.
"""
from __future__ import annotations

import json
from html.parser import HTMLParser
from urllib.parse import urlparse
from typing import Any


RETAILER_HOSTS = {
    "magnit": {"magnit.ru", "www.magnit.ru"},
    "pyaterochka": {"5ka.ru", "www.5ka.ru"},
    "perekrestok": {"perekrestok.ru", "www.perekrestok.ru"},
    "lenta": {"lenta.com", "www.lenta.com"},
    "spar": {"myspar.ru", "www.myspar.ru"},
}


class _JsonLdParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self._capture = False
        self._parts: list[str] = []
        self.documents: list[str] = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == "script":
            values = dict(attrs)
            if values.get("type", "").lower() == "application/ld+json":
                self._capture = True
                self._parts = []

    def handle_data(self, data):
        if self._capture:
            self._parts.append(data)

    def handle_endtag(self, tag):
        if tag.lower() == "script" and self._capture:
            self.documents.append("".join(self._parts))
            self._capture = False
            self._parts = []


def validate_retailer_url(slug: str, url: str) -> bool:
    parsed = urlparse(url)
    return parsed.scheme == "https" and parsed.hostname in RETAILER_HOSTS.get(slug, set())


def _walk_products(value: Any):
    if isinstance(value, list):
        for item in value:
            yield from _walk_products(item)
    elif isinstance(value, dict):
        kind = value.get("@type", [])
        kinds = [kind] if isinstance(kind, str) else kind
        if "Product" in kinds:
            yield value
        graph = value.get("@graph")
        if graph is not None:
            yield from _walk_products(graph)
        for key in ("mainEntity", "itemListElement", "hasOfferCatalog"):
            if key in value:
                yield from _walk_products(value[key])


def parse_jsonld_products(html: str) -> list[dict]:
    parser = _JsonLdParser()
    parser.feed(html)
    found: list[dict] = []
    seen: set[tuple[str, str]] = set()
    for raw in parser.documents:
        try:
            doc = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            continue
        for product in _walk_products(doc):
            name = product.get("name")
            offers = product.get("offers") or {}
            offers_list = offers if isinstance(offers, list) else [offers]
            for offer in offers_list:
                if not isinstance(offer, dict):
                    continue
                price = offer.get("price") or offer.get("lowPrice")
                currency = offer.get("priceCurrency", "RUB")
                if not name or price is None or currency != "RUB":
                    continue
                key = (str(name).strip(), str(price))
                if key in seen:
                    continue
                seen.add(key)
                brand = product.get("brand")
                if isinstance(brand, dict):
                    brand = brand.get("name")
                found.append({
                    "name": str(name).strip(),
                    "price_rub": price,
                    "brand": brand,
                    "barcode": product.get("gtin13") or product.get("gtin") or product.get("gtin8"),
                    "product_id": product.get("sku") or product.get("productID"),
                    "url": product.get("url") or offer.get("url"),
                    "availability": offer.get("availability"),
                })
    return found
