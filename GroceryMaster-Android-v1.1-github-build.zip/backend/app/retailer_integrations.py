from __future__ import annotations
import json
from pathlib import Path
from typing import Any

DATA = Path(__file__).resolve().parents[1] / "data" / "retailer_sources.json"

def load_retailer_registry() -> dict[str, Any]:
    return json.loads(DATA.read_text(encoding="utf-8"))

def public_network_status() -> list[dict[str, Any]]:
    registry = load_retailer_registry()
    return [{
        "slug": n["slug"], "name": n["name"],
        "local_presence": n["local_presence"],
        "catalog_url": n["catalog_url"], "website_url": n["website_url"],
        "connector_type": n["connector_type"],
        "price_feed_status": n["price_feed_status"],
        "automated_price_sync": n["automated_price_sync"],
        "last_successful_sync": n["last_successful_sync"],
        "sync_adapter": n.get("sync_adapter", "authorized_feed"),
        "catalog_url_env": n.get("catalog_url_env"),
        "store_id_env": n.get("store_id_env"),
        "note": n["note"]
    } for n in registry["networks"]]

def source_discovery_links() -> list[dict[str, str]]:
    # Proshoper is used only to discover current local promo/catalog pages;
    # its content is not copied into the price database without permission.
    return [{"name":"Прошопер — каталоги Йошкар-Олы", "url":"https://yoshkar-ola.proshoper.ru/", "role":"catalog_discovery_only"},
            {"name":"Open Food Facts — API продуктов по штрихкоду", "url":"https://openfoodfacts.github.io/openfoodfacts-server/api/", "role":"product_metadata_only_not_prices"}]
