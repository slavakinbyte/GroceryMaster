"""Run the retailer price-feed synchronizer on a configurable interval."""
import asyncio, os
from .price_sync import sync_all

async def main():
    interval = max(300, int(os.getenv('GM_PRICE_SYNC_INTERVAL_SECONDS', '21600')))
    while True:
        result = await sync_all()
        print(f"price sync: {result['successful_sources']} successful / {result['configured_sources']} configured", flush=True)
        await asyncio.sleep(interval)

if __name__ == '__main__':
    asyncio.run(main())
