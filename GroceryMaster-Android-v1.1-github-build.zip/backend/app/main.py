from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, Query, HTTPException, Header
from pydantic import BaseModel, Field
from .price_catalog import public_offers, load_snapshot
from .retailer_integrations import public_network_status, source_discovery_links
from .ingestion import openfoodfacts_product_url, normalize_off_product
from .price_sync import sync_status, sync_all
import os
import httpx

app = FastAPI(
    title="Grocery Master API",
    version="1.0.0",
    description="Backend foundation for the Grocery Master grocery comparison app."
)

class City(BaseModel):
    id: str
    name: str
    region: str
    country_code: str = "RU"

class Store(BaseModel):
    id: str
    name: str
    network: str
    city_id: str
    address: Optional[str] = None

class Product(BaseModel):
    id: str
    name: str
    brand: Optional[str] = None
    category: Optional[str] = None
    quantity_value: Optional[float] = None
    quantity_unit: Optional[str] = None

class PriceOffer(BaseModel):
    product_id: str
    store_id: str
    price_rub: float = Field(gt=0)
    currency: str = "RUB"
    observed_at: datetime
    source: str
    is_promo: bool = False

class PriceComparison(BaseModel):
    product_id: str
    city_id: str
    offers: list[PriceOffer]
    message: str

class AuthCodeRequest(BaseModel):
    method: str = Field(pattern="^(phone|email)$")
    destination: str = Field(min_length=5, max_length=254)

class AuthCodeVerify(BaseModel):
    challenge_id: str
    code: str = Field(min_length=4, max_length=8)

@app.get("/health")
def health():
    return {"status": "ok", "service": "grocery-master-api", "version": "1.0.0"}

@app.get("/v1/cities", response_model=list[City])
def list_cities(q: Optional[str] = Query(default=None, description="City name search")):
    # Intentionally empty until a verified city directory is connected.
    # Never invent city coverage or imply that prices are available.
    return []

@app.get("/v1/stores", response_model=list[Store])
def list_stores(city_id: Optional[str] = None):
    # Store coverage is populated only from verified partner/catalog sources.
    return []

@app.get("/v1/products/search", response_model=list[Product])
def search_products(q: str = Query(min_length=2), city_id: Optional[str] = None):
    # Product catalog ingestion is a separate pipeline.
    return []

@app.get("/v1/prices/compare/{product_id}")
def compare_prices(product_id: str, city_id: str = "yoshkar-ola"):
    matches = [x for x in public_offers() if x["product_id"] == product_id]
    return {"product_id": product_id, "city_id": city_id, "offers": matches,
            "message": "Найден снимок публичного каталога" if matches else "Нет подтверждённых предложений для этого товара."}

@app.get("/v1/prices/latest")
def latest_prices(q: Optional[str] = None, city: str = "Йошкар-Ола"):
    if city.casefold() not in ("йошкар-ола", "yoshkar-ola"):
        return {"city": city, "offers": [], "message": "Для этого города пока нет загруженных ценовых источников."}
    offers = public_offers(q)
    return {"city": "Йошкар-Ола", "count": len(offers), "offers": offers,
            "message": "Публичный снимок каталога Перекрёстка; не live API и не гарантия цены на кассе."}

@app.get("/v1/prices/sources")
def price_sources():
    snap = load_snapshot()
    return [{"slug": snap["source"]["slug"], "name": snap["source"]["name"],
             "url": snap["source"]["url"], "retrieved_date": snap["retrieved_date"],
             "status": "public_snapshot_manual_review", "automated_ingestion_enabled": False,
             "note": snap["source"]["note"]}]


@app.post("/v1/auth/request-code")
def request_auth_code(payload: AuthCodeRequest):
    # Deliberately disabled until an SMS/email provider, rate limiting,
    # challenge storage and abuse controls are configured.
    raise HTTPException(
        status_code=501,
        detail="Authentication delivery provider is not configured yet."
    )

@app.post("/v1/auth/verify-code")
def verify_auth_code(payload: AuthCodeVerify):
    # Never accept demo codes or issue sessions without verified delivery.
    raise HTTPException(
        status_code=501,
        detail="Authentication verification is not configured yet."
    )


@app.get("/v1/catalog/pilot")
def pilot_catalog():
    """Research seed for the Yoshkar-Ola pilot; not a live price/store feed."""
    data_path = Path(__file__).resolve().parents[1] / "data" / "yoshkar_ola_networks.json"
    return json.loads(data_path.read_text(encoding="utf-8"))


class NearbyStore(BaseModel):
    id: str
    name: str
    network: str
    address: str
    latitude: float
    longitude: float
    distance_m: int

@app.get("/v1/stores/nearby", response_model=list[NearbyStore])
def nearby_stores(
    latitude: float = Query(ge=-90, le=90),
    longitude: float = Query(ge=-180, le=180),
    radius_m: int = Query(default=5000, ge=100, le=50000),
    network: Optional[str] = None
):
    """Return nearest verified branches once the geocoded branch registry is populated."""
    # No coordinates are seeded from guesswork. Until verified branch coordinates
    # are imported, return an empty list rather than fabricated distances.
    return []

@app.get("/v1/location/geocode")
def geocode_address(address: str = Query(min_length=5, max_length=300)):
    """Address-to-coordinate contract; requires a configured geocoding provider."""
    raise HTTPException(
        status_code=501,
        detail="Geocoding provider is not configured. No address was sent to an external service."
    )


@app.get("/v1/integrations/networks")
def integrations_networks():
    """Network connector registry. A listed catalog is not a live price feed."""
    return {"city": "Йошкар-Ола", "networks": public_network_status(),
            "discovery_sources": source_discovery_links(),
            "note": "Коннекторы подготовлены; цены не считаются live до успешной загрузки с подтверждённой привязкой к магазину."}

@app.get("/v1/integrations/sources")
def integration_sources():
    return source_discovery_links()

@app.get("/v1/products/barcode/{barcode}")
async def product_by_barcode(barcode: str):
    """Fetch food metadata from Open Food Facts; deliberately never returns a store price."""
    try:
        url = openfoodfacts_product_url(barcode)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    headers = {"User-Agent": os.getenv("OFF_USER_AGENT", "GroceryMaster/0.9 (contact: configure-admin-email)")}
    timeout = httpx.Timeout(8.0, connect=4.0)
    try:
        async with httpx.AsyncClient(timeout=timeout, headers=headers) as client:
            response = await client.get(url)
            response.raise_for_status()
            payload = response.json()
    except (httpx.HTTPError, ValueError):
        raise HTTPException(status_code=502, detail="Open Food Facts временно недоступен")
    normalized = normalize_off_product(payload)
    if not normalized:
        raise HTTPException(status_code=404, detail="Штрихкод не найден в Open Food Facts")
    return normalized

@app.get("/v1/prices/sync-status")
def price_sync_status():
    """Last automatic feed run and count of collected observations awaiting review."""
    return sync_status()

@app.post("/v1/admin/prices/sync")
async def trigger_price_sync(x_admin_token: Optional[str] = Header(default=None)):
    """Run configured, authorized HTTPS retailer feeds now; no unconfigured source is scraped."""
    expected = os.getenv("GM_ADMIN_IMPORT_TOKEN")
    if not expected or x_admin_token != expected:
        raise HTTPException(status_code=401, detail="Admin import token is missing or invalid")
    return await sync_all()

@app.get("/v1/prices/coverage")
def price_coverage():
    networks = public_network_status()
    return {
        "city": "Йошкар-Ола",
        "networks_listed": len(networks),
        "networks_with_authorized_automated_price_feed": sum(1 for n in networks if n["automated_price_sync"]),
        "networks_with_public_price_snapshot": 1,
        "warning": "Каталоги и ссылки не равны автоматическому фиду. На текущем этапе только Перекрёсток имеет сохранённый ценовой снимок; для остальных требуется официальный API/партнёрский фид или ручной импорт с правом использования."
    }

class PriceImportRequest(BaseModel):
    csv_content: str = Field(min_length=1, max_length=2_000_000)
    source_slug: str = Field(min_length=2, max_length=80)

@app.post("/v1/admin/import/price-csv")
def import_price_csv(payload: PriceImportRequest, x_admin_token: Optional[str] = Header(default=None)):
    """Validate and stage a partner CSV. Does not publish rows or persist without DB review."""
    expected = os.getenv("GM_ADMIN_IMPORT_TOKEN")
    if not expected or x_admin_token != expected:
        raise HTTPException(status_code=401, detail="Admin import token is missing or invalid")
    from .ingestion import parse_retail_csv
    rows = parse_retail_csv(payload.csv_content, payload.source_slug)
    return {"received": len(rows), "published": 0, "status": "requires_review",
            "rows": rows, "message": "Импорт проверен, но цены не опубликованы: нужна модерация и сохранение в БД."}
