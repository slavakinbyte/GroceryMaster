from decimal import Decimal
import re
UNIT_ALIASES={"г":"g","гр":"g","g":"g","кг":"kg","kg":"kg","мл":"ml","ml":"ml","л":"l","литр":"l","l":"l","шт":"pcs","штука":"pcs","pcs":"pcs"}
def normalize_unit(unit):
    key=unit.strip().lower().replace(".","")
    if key not in UNIT_ALIASES: raise ValueError(f"Unsupported unit: {unit}")
    return UNIT_ALIASES[key]
def to_base_quantity(value,unit):
    amount=Decimal(str(value))
    if amount<=0: raise ValueError("Quantity must be positive")
    u=normalize_unit(unit)
    factors={"g":Decimal("1"),"kg":Decimal("1000"),"ml":Decimal("1"),"l":Decimal("1000"),"pcs":Decimal("1")}
    bases={"g":"g","kg":"g","ml":"ml","l":"ml","pcs":"pcs"}
    return amount*factors[u],bases[u]
def unit_price(price,quantity,unit):
    p=Decimal(str(price)); q,base=to_base_quantity(quantity,unit)
    if p<=0: raise ValueError("Price must be positive")
    divisor=Decimal("1000") if base in ("g","ml") else Decimal("1")
    label={"g":"RUB/kg","ml":"RUB/l","pcs":"RUB/pcs"}[base]
    return (p/(q/divisor)).quantize(Decimal("0.0001")),label
def valid_gtin(code):
    digits=re.sub(r"\s|-","",str(code))
    if not digits.isdigit() or len(digits) not in (8,12,13,14): return False
    nums=[int(x) for x in digits]; check=nums.pop()
    total=sum(n*(3 if (len(nums)-i)%2==1 else 1) for i,n in enumerate(nums))
    return (10-total%10)%10==check
