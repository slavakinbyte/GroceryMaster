from __future__ import annotations
import json
from datetime import date
from decimal import Decimal
from pathlib import Path
from .catalog_core import unit_price

DATA = Path(__file__).resolve().parents[1] / "data" / "price_snapshots" / "perekrestok_yola_2026-11-25.json"

def load_snapshot():
    return json.loads(DATA.read_text(encoding="utf-8"))

def public_offers(q: str | None = None):
    snap = load_snapshot()
    out = []
    for item in snap["products"]:
        if q and q.casefold() not in item["name"].casefold():
            continue
        # Produce comparable RUB/kg or RUB/l only when the source gives a package quantity.
        normalized, normalized_unit = unit_price(item["price_rub"], item["quantity"], item["unit"])
        out.append({
            "product_id": item["external_id"], "name": item["name"], "category": item["category"],
            "barcode": item.get("barcode"), "package_quantity": item["quantity"], "package_unit": item["unit"],
            "price_rub": item["price_rub"], "regular_price_rub": item.get("regular_price_rub"),
            "is_promo": item.get("is_promo", False), "stock_status": item.get("stock_status", "unknown"),
            "normalized_price": str(normalized), "normalized_unit": normalized_unit,
            "store": snap["store"], "source": snap["source"],
            "retrieved_date": snap["retrieved_date"], "freshness": snap["freshness"],
            "warning": "Снимок публичной страницы; наличие и цена требуют перепроверки перед покупкой."
        })
    return out
