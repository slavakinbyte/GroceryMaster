"""Scheduled ingestion for retailer-provided JSON/CSV price feeds.

Only explicitly configured, authorized feed URLs are fetched. Public website scraping
is intentionally not enabled by this worker.
"""
from __future__ import annotations
import csv, io, json, os, re
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any
import httpx
from .retailer_adapters import parse_jsonld_products, validate_retailer_url

BASE = Path(__file__).resolve().parents[1]
REGISTRY = BASE / "data" / "retailer_sources.json"
OBSERVATIONS = BASE / "data" / "price_observations.jsonl"
SYNC_STATE = BASE / "data" / "price_sync_state.json"


def _read_json(path: Path, fallback: Any):
    try: return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError): return fallback


def _write_state(state: dict):
    SYNC_STATE.parent.mkdir(parents=True, exist_ok=True)
    tmp = SYNC_STATE.with_suffix('.tmp')
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(SYNC_STATE)


def _normalize_record(row: dict, slug: str, network: str, observed_at: str) -> dict | None:
    name = str(row.get('name') or row.get('title') or '').strip()
    raw_price = row.get('price_rub', row.get('price'))
    if not name or raw_price is None: return None
    try: price = Decimal(str(raw_price).replace(' ', '').replace(',', '.'))
    except InvalidOperation: return None
    if not price.is_finite() or price <= 0 or price > Decimal('10000000'): return None
    quantity = str(row.get('quantity') or row.get('unit') or '').strip() or None
    barcode = re.sub(r'\D', '', str(row.get('barcode') or row.get('gtin') or '')) or None
    return {
        'network_slug': slug, 'network_name': network,
        'store_id': str(row.get('store_id') or row.get('shop_id') or '') or None,
        'product_external_id': str(row.get('product_id') or row.get('sku') or '') or None,
        'barcode': barcode, 'name': name, 'brand': row.get('brand'),
        'quantity': quantity, 'price_rub': str(price),
        'old_price_rub': str(row.get('old_price')) if row.get('old_price') not in (None, '') else None,
        'is_promo': bool(row.get('is_promo') or row.get('promo')),
        'product_url': row.get('url') or row.get('product_url'),
        'source_url': row.get('source_url'), 'observed_at': observed_at,
        'status': 'requires_review'
    }


def _extract_rows(payload: Any, fmt: str) -> list[dict]:
    if fmt == 'csv':
        return list(csv.DictReader(io.StringIO(payload)))
    if isinstance(payload, dict):
        for key in ('items', 'products', 'offers', 'data'):
            if isinstance(payload.get(key), list): return payload[key]
        return []
    return payload if isinstance(payload, list) else []


async def sync_one(network: dict, client: httpx.AsyncClient) -> dict:
    slug, name = network['slug'], network['name']
    env_name = network.get('feed_url_env') or f"GM_FEED_URL_{slug.upper().replace('-', '_')}"
    mode = network.get('sync_adapter', 'authorized_feed')
    url = os.getenv(env_name, '').strip()
    if mode == 'jsonld_catalog':
        url_env = network.get('catalog_url_env') or f"GM_CATALOG_URL_{slug.upper().replace('-', '_')}"
        url = os.getenv(url_env, '').strip()
        if not url:
            return {'slug': slug, 'name': name, 'status': 'not_configured', 'received': 0,
                    'detail': f'Нужна проверенная публичная страница каталога в {url_env}; сбор не включён.'}
        if not validate_retailer_url(slug, url):
            return {'slug': slug, 'name': name, 'status': 'rejected_unapproved_host', 'received': 0}
        store_env = network.get('store_id_env') or f"GM_STORE_ID_{slug.upper().replace('-', '_')}"
        store_context = os.getenv(store_env, '').strip()
        if not store_context:
            return {'slug': slug, 'name': name, 'status': 'missing_store_context', 'received': 0,
                    'detail': f'Нужен подтверждённый ID магазина Йошкар-Олы в {store_env}; общие цены без привязки не импортируются.'}
    elif not network.get('feed_enabled') or not url:
        return {'slug': slug, 'name': name, 'status': 'not_configured', 'received': 0,
                'detail': f'Нужен разрешённый URL фида в переменной {env_name}; автоматический сбор не включён.'}
    elif not url.startswith('https://'):
        return {'slug': slug, 'name': name, 'status': 'rejected_insecure_url', 'received': 0}
    try:
        response = await client.get(url)
        response.raise_for_status()
        if mode == 'jsonld_catalog':
            rows = parse_jsonld_products(response.text)
        else:
            fmt = network.get('feed_format', 'json')
            payload = response.text if fmt == 'csv' else response.json()
            rows = _extract_rows(payload, fmt)
        now = datetime.now(timezone.utc).isoformat()
        normalized = [x for x in (_normalize_record(r, slug, name, now) for r in rows if isinstance(r, dict)) if x]
        for item in normalized:
            item['source_adapter'] = mode
            item['store_id'] = item.get('store_id') or (store_context if mode == 'jsonld_catalog' else network.get('store_id'))
            item['source_url'] = url
        if normalized:
            OBSERVATIONS.parent.mkdir(parents=True, exist_ok=True)
            with OBSERVATIONS.open('a', encoding='utf-8') as f:
                for item in normalized: f.write(json.dumps(item, ensure_ascii=False) + '\n')
        return {'slug': slug, 'name': name, 'status': 'success' if normalized else 'empty_or_invalid',
                'received': len(rows), 'accepted_for_review': len(normalized), 'synced_at': now}
    except (httpx.HTTPError, ValueError, TypeError) as exc:
        return {'slug': slug, 'name': name, 'status': 'error', 'received': 0,
                'detail': f'{type(exc).__name__}: {str(exc)[:240]}'}


async def sync_all() -> dict:
    registry = _read_json(REGISTRY, {'networks': []})
    results = []
    timeout = httpx.Timeout(20.0, connect=8.0)
    headers = {'User-Agent': os.getenv('GM_FEED_USER_AGENT', 'GroceryMasterPriceSync/1.0')}
    async with httpx.AsyncClient(timeout=timeout, headers=headers, follow_redirects=False) as client:
        for network in registry.get('networks', []):
            results.append(await sync_one(network, client))
    state = {'checked_at': datetime.now(timezone.utc).isoformat(), 'results': results,
             'configured_sources': sum(r['status'] != 'not_configured' for r in results),
             'successful_sources': sum(r['status'] == 'success' for r in results)}
    _write_state(state)
    return state


def sync_status() -> dict:
    state = _read_json(SYNC_STATE, {'checked_at': None, 'results': []})
    state['observation_count'] = sum(1 for _ in OBSERVATIONS.open(encoding='utf-8')) if OBSERVATIONS.exists() else 0
    return state
