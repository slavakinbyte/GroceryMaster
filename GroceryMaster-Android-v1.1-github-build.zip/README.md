# Grocery Master — Android + backend foundation (v0.2)

Первый проектный каркас для общедоступного приложения. Первый пилотный город — Йошкар-Ола; модель данных допускает подключение других городов РФ.

## Android
- Kotlin + Jetpack Compose
- Главный экран, магазины, корзина, меню, бюджет
- Текущий UI — прототип; цены и ассортимент не подключены

Откройте корневую папку в Android Studio, выполните Gradle Sync и запустите конфигурацию `app`.

## Backend
В папке `backend/` находится минимальный FastAPI-каркас:
```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
После запуска: `http://127.0.0.1:8000/docs`

## Документация
- `docs/PRODUCT_REQUIREMENTS.md` — сценарии и границы MVP
- `docs/DATA_MODEL.md` — сущности и связи
- `docs/API.md` — API v0.2

## Честный статус
Это исходный код прототипа и backend-каркаса, а не опубликованное приложение и не готовая production-система. Реальные цены, наличие, адреса и скидки появятся после подключения и проверки законных источников данных. Сейчас API не выдаёт фиктивные цены.

## Следующие технические задачи
1. Проверить и зафиксировать список магазинов/торговых точек пилотного города.
2. Проверить официальные способы получения каталогов и цен каждой сети.
3. Подключить PostgreSQL и миграции.
4. Реализовать загрузчики источников, дедупликацию и нормализацию фасовок.
5. Добавить Room/синхронизацию на Android и пользовательские профили.
6. Написать тесты и настроить сборку APK.


## Authentication decision
The first release supports phone number or email using one-time verification codes. The Android account screen is currently a UI prototype. Backend auth endpoints deliberately return HTTP 501 until a real provider and security controls are configured; no fake codes are accepted.
See `docs/AUTHENTICATION.md`.


## Monetization decision
The initial product is fully free and ad-free. No advertising, subscription, paywall, ad SDK or payment SDK is part of the initial release. Any future monetization requires a separate product decision.
See `docs/MONETIZATION.md`.


## Yoshkar-Ola pilot catalog
The initial network research seed is in `backend/data/yoshkar_ola_networks.json`; research notes and sources are in `docs/LOCAL_CATALOG_RESEARCH.md`. This is not an exhaustive verified branch directory and contains no live prices. Do not present research listings as official store confirmation.


## v0.6 — поиск ближайших магазинов и расширенный список сетей
- Добавлены дополнительные локальные сети и продуктовые магазины-кандидаты Йошкар-Олы в `backend/data/yoshkar_ola_networks.json`.
- Добавлен API-контракт для поиска ближайших точек по координатам и геокодирования введённого адреса.
- Описан сценарий ручного ввода адреса и добровольного разрешения геолокации Android.
- Поиск пока не выдаёт выдуманные расстояния: геокодер и проверенные координаты филиалов ещё не подключены.
См. `docs/NEARBY_STORES.md`.


## v0.7 — товарный каталог и источники данных
- Добавлена PostgreSQL schema: Product / ProductVariant / Barcode / Store / DataSource / PriceObservation / ingestion audit.
- Добавлена нормализация g/kg/ml/l/pcs и расчёт сопоставимой цены за кг/л/шт.
- Добавлена проверка контрольной цифры GTIN-8/12/13/14.
- Добавлен импортёр партнёрского CSV с обязательным статусом `requires_review`.
- Добавлен адаптер Open Food Facts для обогащения метаданных; OFF не используется как источник цен.
- Добавлены архитектура каталога, стратегия источников и CSV contract.
- Тесты: `cd backend && pip install -r requirements-dev.txt && pytest`.
- Миграция: выполнить `backend/db/001_initial_schema.sql` в PostgreSQL.
- Реальные цены не загружаются без разрешённого источника и проверенного сопоставления SKU/магазина.


## v0.8 — реальные ценовые наблюдения

Первый источник цен добавлен: публичный каталог конкретного магазина Перекрёсток №70 в Йошкар-Оле, 6 товарных предложений. Это датированный снимок публичной страницы, не live API и не гарантия цены на кассе. См. `docs/REAL_PRICE_DATA.md`. API: `/v1/prices/latest`, `/v1/prices/sources`. Автоматический парсинг сайтов не включён до проверки условий и разрешений.


## v0.9 retailer integrations
See `docs/RETAIL_INTEGRATIONS_V0.9.md`. The registry includes 23 networks and discovery links, Open Food Facts barcode metadata lookup, and a protected CSV staging endpoint. Only the existing Perekrestok snapshot contains prices; other networks are not falsely labelled as live feeds.

## Автоматическая загрузка цен (v1.0)

Добавлен отдельный worker для расписания и загрузки разрешённых JSON/CSV-фидов сетей. Инструкция: `docs/AUTOMATIC_PRICE_SYNC_V1.0.md`. Worker запускается командой `python -m app.price_sync_worker`; по умолчанию проверяет настроенные источники раз в 6 часов. Все 23 источника пока выключены до получения реальных HTTPS URL фидов и разрешений сетей — наличие адаптера не означает наличие live-цен.

### Retailer connector adapters v1.1

Provider-specific JSON-LD catalog adapters are prepared for Magnit, Pyaterochka, Perekrestok, Lenta and SPAR. They require a verified official branch-specific catalog URL and Yoshkar-Ola store ID; arbitrary hosts, non-RUB offers and unscoped prices are rejected. Imported observations remain in review. See `docs/RETAILER_CONNECTORS_V1.1.md` and `docker-compose.price-worker.yml`.
