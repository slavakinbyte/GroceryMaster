# Retail integrations — v0.9

## What is connected now
- A normalized connector registry for 23 retail/delivery networks relevant to the Yoshkar-Ola pilot.
- Official public catalog/website links where found, plus a local catalog-discovery directory.
- Open Food Facts barcode lookup for product metadata only (never prices).
- Admin-protected CSV staging endpoint for authorized retailer/partner price feeds.
- Coverage/status endpoints that explicitly distinguish catalog discovery, saved snapshots, and authorized automated feeds.

## What is NOT connected
No official machine-readable price feed credentials have been provided by Magnit, Pyaterochka, Lenta, SPAR, Chizhik, etc. Therefore these networks are not represented as live price integrations. Public web catalogs and third-party catalog aggregators may be viewed for discovery, but automated extraction/republication is disabled until terms/permission are reviewed.

## API
- `GET /v1/integrations/networks`
- `GET /v1/integrations/sources`
- `GET /v1/prices/coverage`
- `GET /v1/products/barcode/{gtin}` — Open Food Facts metadata lookup
- `POST /v1/admin/import/price-csv` — staged CSV import; requires `GM_ADMIN_IMPORT_TOKEN` and `X-Admin-Token`; rows remain unpublished pending review.

## Open Food Facts
Uses API v3 product lookup by GTIN. Follow OFF terms, ODbL/DBCL attribution and rate limits. Set a meaningful `OFF_USER_AGENT` contact value before deployment. Data is community-contributed and must be quality-reviewed.

## Price feed onboarding checklist for each retailer
1. Obtain written permission, API credentials, or partner export.
2. Confirm city/store identifiers and whether prices are online, pickup, or in-store.
3. Map retailer SKU and GTIN to canonical product/variant/package.
4. Import with source URL, observed timestamp, currency, promo/loyalty conditions, and stock status.
5. Review duplicates and anomalies; publish only after validation.
6. Keep price history and expire stale offers automatically.
