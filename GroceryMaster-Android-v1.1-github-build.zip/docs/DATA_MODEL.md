# Модель данных (первый контур)

## City
`id`, `name`, `region`, `country_code`, `timezone`, `is_active`

## StoreNetwork
`id`, `name`, `website`, `data_access_method`, `terms_reviewed_at`

## StoreLocation
`id`, `network_id`, `city_id`, `address`, `latitude`, `longitude`, `delivery_available`

## Product
`id`, `canonical_name`, `brand`, `category_id`, `barcode`, `quantity_value`, `quantity_unit`

## ProductVariant
`id`, `product_id`, `display_name`, `package_quantity`, `package_unit`, `barcode`

## PriceOffer
`id`, `variant_id`, `store_location_id`, `price_minor`, `currency`, `is_promo`, `source_id`, `observed_at`, `expires_at`

## DataSource
`id`, `name`, `source_type`, `terms_url`, `refresh_interval_minutes`, `is_enabled`

## UserProfile
`id`, `city_id`, `household_size`, `weekly_budget_minor`, `currency`, `created_at`

## ShoppingList / ShoppingListItem
Список пользователя и позиции с количеством, единицей измерения, выбранным товаром и статусом покупки.

## MealPlan / Recipe / RecipeIngredient
План питания, рецепт и связь ингредиентов с нормализованными товарами.

### Денежные значения
Хранить в целых минимальных денежных единицах (копейках), не в `Float`.

### Важные связи
- Цена относится к конкретному варианту товара и конкретной торговой точке.
- Город сам по себе не гарантирует наличие товара: наличие и цена привязаны к точке/каналу доставки.
- Источник и время получения обязательны для каждого предложения.
