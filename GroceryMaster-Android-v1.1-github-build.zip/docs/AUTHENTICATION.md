# Authentication design

## User-selected methods
- Phone number (SMS one-time code)
- Email address (email one-time code)

No Google or social sign-in in the first release.

## Intended flow
1. User submits phone or email.
2. API normalizes and validates the destination.
3. API creates a short-lived challenge and sends a one-time code through the configured provider.
4. User submits the code.
5. API verifies the challenge, marks it consumed, and issues short-lived access plus rotating refresh tokens.
6. User profile, shopping lists, meal plans and preferences are associated with the account.

## Security requirements before enabling production auth
- Never log one-time codes or raw tokens.
- Store only a secure hash of each code; use a cryptographically secure random generator.
- Expire codes quickly, make them single-use, and invalidate older challenges when appropriate.
- Rate-limit by destination, IP/device and account; add abuse detection.
- Avoid revealing whether an email or phone is already registered.
- Protect refresh tokens, support revocation and logout from devices.
- Use TLS in production.
- Provide account deletion and personal-data export workflows.
- Define retention periods and privacy notice before public release.

## Current implementation status
The Android account screen is a UI prototype. Backend endpoints are deliberately disabled with HTTP 501 until a real SMS/email delivery provider, secure challenge storage, rate limiting and token management are implemented. No code is sent and no account is created yet.
