# Monetization decision

## Current product decision
Grocery Master launches as a fully free application with no advertising.

## Product constraints for the initial releases
- No banner, interstitial, rewarded or native ads.
- No paid subscription or paywall.
- Core features remain available without payment.
- Do not add ad SDKs or payment/subscription SDKs to the initial Android build.
- Do not design features around artificial limits intended to push users toward payment.

## Future review
Monetization may be reconsidered later, only after a separate product decision with the user. No future model is assumed or preselected.
