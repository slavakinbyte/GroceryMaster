# Automatic retailer price sync — v1.0

## What is implemented

- A separate async worker: `python -m app.price_sync_worker`.
- Configurable interval via `GM_PRICE_SYNC_INTERVAL_SECONDS` (default 6 hours; minimum 5 minutes).
- Per-network feed configuration in `backend/data/retailer_sources.json`.
- HTTPS-only JSON and CSV feed ingestion. JSON accepts a top-level list or `items`/`products`/`offers`/`data` array. CSV uses headers.
- Normalization of product name, external ID, barcode, pack/unit, current/old price, promo flag, product URL and observation timestamp.
- Append-only observation storage in `backend/data/price_observations.jsonl` and run status in `backend/data/price_sync_state.json`.
- `GET /v1/prices/sync-status` for operational status.
- `POST /v1/admin/prices/sync` for an authenticated manual run using `GM_ADMIN_IMPORT_TOKEN` / `X-Admin-Token`.
- All fetched rows are marked `requires_review`; the worker does not silently publish unmoderated prices.

## Configure an authorized retailer feed

1. Obtain a documented partner feed/API endpoint and permission to use it.
2. Set its HTTPS URL in the matching environment variable, e.g. `GM_FEED_URL_MAGNIT`.
3. Set that network's `feed_enabled` to `true` and `feed_format` to `json` or `csv` in `retailer_sources.json`.
4. Start the worker alongside the API: `python -m app.price_sync_worker`.
5. Review rows in `price_observations.jsonl` before publication.

Normalized input fields: `name`/`title`, `price_rub`/`price`, optional `quantity`/`unit`, `barcode`/`gtin`, `product_id`/`sku`, `store_id`/`shop_id`, `brand`, `old_price`, `is_promo`/`promo`, `url`/`product_url`.

## Current honest status

All 23 registry entries are initially `feed_enabled: false`. No retailer credentials, partner feed URLs, or permissions were present in the project, so this release adds a working ingestion and scheduling mechanism but does **not** claim that any new chain is already sending live prices. The existing Perekrestok file remains a dated public snapshot, not a live feed. Public-site scraping, login automation, CAPTCHA bypass and undocumented internal endpoints are not enabled.

The worker writes observations to a JSONL staging file. Production deployment still needs durable database storage, moderation/publication workflow, monitoring, and feed credentials/agreements.
