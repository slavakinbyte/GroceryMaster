# Формат партнёрского CSV

Обязательные столбцы:
`store_external_id,barcode,name,brand,quantity,unit,price_rub,observed_at,source_url`

Дополнительные:
`regular_price_rub,is_promo,stock_status,external_product_id,category`

Единицы: `g`, `kg`, `ml`, `l`, `pcs` (допускаются русские aliases в нормализаторе). Дата ISO-8601 с timezone. Каждая запись импортируется как `requires_review`; перед публикацией проверяются магазин, SKU/штрихкод, цена, время и права на источник. Пустой или неверный barcode не заменяется догадкой.
