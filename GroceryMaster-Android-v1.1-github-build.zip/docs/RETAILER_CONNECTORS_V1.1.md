# Retailer connectors v1.1 — Yoshkar-Ola

## What is implemented

- Provider-specific adapter selection for Magnit, Pyaterochka, Perekrestok, Lenta and SPAR.
- `jsonld_catalog` adapter reads Product/Offer JSON-LD from an explicitly configured official retailer page.
- Strict HTTPS host allowlist per retailer; arbitrary hosts and HTTP are rejected.
- JSON-LD prices are accepted only in RUB.
- Store context is mandatory (`GM_STORE_ID_*`). Generic national/homepage prices are not imported as Yoshkar-Ola branch prices.
- Every accepted observation is tagged with adapter and exact source URL, then staged as `requires_review`.
- Existing authorized JSON/CSV partner feed support remains available for networks that supply a feed.
- No CAPTCHA, login, bot-protection, session, or access-control bypass is implemented.

## Five initial networks

| Network | Adapter | Catalog URL env | Store ID env | Current state |
|---|---|---|---|---|
| Magnit | JSON-LD catalog | `GM_CATALOG_URL_MAGNIT` | `GM_STORE_ID_MAGNIT` | Awaiting verified branch page and store ID |
| Pyaterochka | JSON-LD catalog | `GM_CATALOG_URL_PYATEROCHKA` | `GM_STORE_ID_PYATEROCHKA` | Awaiting verified branch page and store ID |
| Perekrestok | JSON-LD catalog | `GM_CATALOG_URL_PEREKRESTOK` | `GM_STORE_ID_PEREKRESTOK` | Snapshot exists; recurring branch feed not connected |
| Lenta | JSON-LD catalog | `GM_CATALOG_URL_LENTA` | `GM_STORE_ID_LENTA` | Awaiting verified branch page and store ID |
| SPAR | JSON-LD catalog | `GM_CATALOG_URL_SPAR` | `GM_STORE_ID_SPAR` | Awaiting verified branch page and store ID |

The connector is prepared, not falsely marked as connected. A URL must be a permitted public catalog page on the official host, expose machine-readable Product/Offer JSON-LD, and be specific to the intended Yoshkar-Ola store. If the retailer requires an agreement or authenticated partner feed, use that feed instead.

## Configure after source verification

Copy `backend/.env.example` to `backend/.env` and set the relevant values only after confirming the retailer's terms and branch context. Example (placeholders, not working URLs):

```dotenv
GM_CATALOG_URL_MAGNIT=https://magnit.ru/<verified-branch-catalog-page>
GM_STORE_ID_MAGNIT=<verified-yoshkar-ola-store-id>
```

Never put credentials in the repository. Use deployment secrets for partner credentials and tokens.

## Run

One-off sync from backend directory:

```bash
python -m app.price_sync_worker
```

Separate Docker worker:

```bash
docker compose -f docker-compose.price-worker.yml up -d --build
```

Default interval: six hours (`GM_PRICE_SYNC_INTERVAL_SECONDS=21600`, minimum five minutes).

## API status

- `GET /v1/integrations/networks` — configured adapter and required environment variable names.
- `GET /v1/prices/sync-status` — last sync status and observation count.
- `POST /v1/admin/prices/sync` — admin-triggered sync (requires `GM_ADMIN_IMPORT_TOKEN`).

## Important publication rules

The worker writes observations as `requires_review`. It does not publish imported prices to end users. Review must confirm product identity, branch, unit/pack size, price basis, promo conditions, and freshness. Prices that cannot be tied to a Yoshkar-Ola branch are not accepted. An empty JSON-LD response is not evidence that a store has no products.

## Current limitation

At build time, live retailer credentials, approved feed URLs, and verified branch-specific catalog page IDs were not available. Therefore none of these five networks is represented as a live connected price source yet. The adapter code and deployment worker are ready for verified source configuration; this is not a claim that all five feeds already work.
