package ru.grocerymaster.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF176B4D)
private val Pale = Color(0xFFEAF4EE)
private val Ink = Color(0xFF17231D)
private val Muted = Color(0xFF68766F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GroceryMasterApp() }
    }
}

data class Store(val name: String, val note: String)
data class Product(val name: String, val amount: String, val price: String, val store: String)

@Composable
fun GroceryMasterApp() {
    var tab by remember { mutableStateOf("Главная") }
    var budget by remember { mutableStateOf("10000") }
    var checked by remember { mutableStateOf(setOf<String>()) }

    val stores = listOf(
        Store("Пятёрочка", "Каталог и онлайн-цены — подключение готовится"),
        Store("Магнит", "Каталог и онлайн-цены — подключение готовится"),
        Store("Чижик", "Акционные предложения — подключение готовится"),
        Store("Перекрёсток", "Есть публичная витрина для Йошкар-Олы"),
        Store("Лента", "Проверяем доступность ассортимента в городе"),
        Store("SPAR / Eurospar", "Локальные каталоги и предложения")
    )
    val demoProducts = listOf(
        Product("Молоко 2,5%", "1 л", "Демо-цена", "Магазин будет уточнён"),
        Product("Яйца С1", "10 шт.", "Демо-цена", "Магазин будет уточнён"),
        Product("Гречка", "800 г", "Демо-цена", "Магазин будет уточнён"),
        Product("Куриное филе", "1 кг", "Демо-цена", "Магазин будет уточнён")
    )

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            background = Color(0xFFF7F9F7),
            surface = Color.White,
            onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Color(0xFFF7F9F7),
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Главная", "Магазины", "Корзина", "Меню", "Бюджет", "Аккаунт").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Text(when(item) {
                                "Главная" -> "⌂"; "Магазины" -> "▦"; "Корзина" -> "🛒"
                                "Меню" -> "♨"; "Бюджет" -> "₽"; else -> "●"
                            }, fontSize = 18.sp) },
                            label = { Text(item, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            when (tab) {
                "Главная" -> HomeScreen(padding, onGo = { tab = it })
                "Магазины" -> StoresScreen(padding, stores)
                "Корзина" -> BasketScreen(padding, demoProducts, checked) { name, value ->
                    checked = if (value) checked + name else checked - name
                }
                "Меню" -> MenuScreen(padding)
                "Бюджет" -> BudgetScreen(padding, budget) { budget = it }
                else -> AccountScreen(padding)
            }
        }
    }
}

@Composable
fun Page(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxSize().padding(horizontal = 20.dp), content = content)
}

@Composable
fun HomeScreen(padding: PaddingValues, onGo: (String) -> Unit) {
    Page(Modifier.padding(padding)) {
        Spacer(Modifier.height(22.dp))
        Text("GROCERY MASTER", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Text("Покупки с умом.", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Йошкар-Ола · твой продуктовый помощник", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(22.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Green), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("Твой недельный бюджет", color = Color.White.copy(alpha = .8f))
                Text("10 000 ₽", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text("Демо-настройка — измени её в разделе «Бюджет»", color = Color.White.copy(alpha = .8f), fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Что будем делать?", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        HomeTile("Сравнить магазины", "Найти выгодные предложения", "Магазины") { onGo(it) }
        HomeTile("Собрать корзину", "Список продуктов на неделю", "Корзина") { onGo(it) }
        HomeTile("Составить меню", "Рецепты под бюджет и продукты дома", "Меню") { onGo(it) }
        HomeTile("Контролировать расходы", "Настроить лимит на питание", "Бюджет") { onGo(it) }
        HomeTile("Войти или создать аккаунт", "Сохранить корзину и меню на всех устройствах", "Аккаунт") { onGo(it) }
        Spacer(Modifier.height(12.dp))
        Text("Важно: пока это интерфейсный прототип. Цены не загружаются и не являются реальными.", color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
fun HomeTile(title: String, subtitle: String, destination: String, onClick: (String) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onClick(destination) },
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, color = Ink)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
            Text("›", color = Green, fontSize = 28.sp)
        }
    }
}

@Composable
fun StoresScreen(padding: PaddingValues, stores: List<Store>) {
    Page(Modifier.padding(padding)) {
        Spacer(Modifier.height(24.dp))
        Text("Магазины", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Сети, которые будем подключать в Йошкар-Оле", color = Muted)
        Spacer(Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(stores) { store ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(store.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(store.note, color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun BasketScreen(padding: PaddingValues, products: List<Product>, checked: Set<String>, onCheck: (String, Boolean) -> Unit) {
    Page(Modifier.padding(padding)) {
        Spacer(Modifier.height(24.dp))
        Text("Моя корзина", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Пример списка — отметь то, что уже куплено", color = Muted)
        Spacer(Modifier.height(12.dp))
        products.forEach { p ->
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = p.name in checked, onCheckedChange = { onCheck(p.name, it) })
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.SemiBold)
                        Text("${p.amount} · ${p.store}", color = Muted, fontSize = 11.sp)
                    }
                    Text(p.price, color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Дальше добавим подбор самого дешёвого магазина и распределение товаров по точкам.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun MenuScreen(padding: PaddingValues) {
    Page(Modifier.padding(padding)) {
        Spacer(Modifier.height(24.dp))
        Text("Меню на неделю", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Планировщик питания", color = Muted)
        Spacer(Modifier.height(16.dp))
        listOf("Понедельник · Курица с гречкой", "Вторник · Омлет и овощной салат", "Среда · Макароны с томатным соусом", "Четверг · Картофель и рыба", "Пятница · Овощное рагу").forEach {
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Text(it, Modifier.padding(16.dp), fontWeight = FontWeight.Medium)
            }
        }
        Text("Это пример меню. Персональный расчёт порций, предпочтений и стоимости добавим следующим этапом.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun BudgetScreen(padding: PaddingValues, budget: String, onBudget: (String) -> Unit) {
    Page(Modifier.padding(padding)) {
        Spacer(Modifier.height(24.dp))
        Text("Бюджет", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Сколько планируем тратить на продукты за неделю?", color = Muted)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(
            value = budget,
            onValueChange = { onBudget(it.filter(Char::isDigit).take(7)) },
            label = { Text("Бюджет, ₽ в неделю") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(Modifier.height(12.dp))
        Text("Сумма сохраняется только в текущем запуске прототипа. Постоянное хранение добавим через локальную базу.", color = Muted, fontSize = 12.sp)
    }
}


@Composable
fun AccountScreen(padding: PaddingValues) {
    var method by remember { mutableStateOf("Телефон") }
    var contact by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }

    Page(Modifier.padding(padding)) {
        Spacer(Modifier.height(24.dp))
        Text("Твой аккаунт", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Сохраняй корзину, меню и бюджет между устройствами", color = Muted)
        Spacer(Modifier.height(20.dp))
        Text("Способ входа", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = method == "Телефон",
                onClick = { method = "Телефон"; contact = ""; notice = "" },
                label = { Text("Телефон") }
            )
            FilterChip(
                selected = method == "Email",
                onClick = { method = "Email"; contact = ""; notice = "" },
                label = { Text("Email") }
            )
        }
        OutlinedTextField(
            value = contact,
            onValueChange = { contact = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text(if (method == "Телефон") "Номер телефона" else "Электронная почта") },
            placeholder = { Text(if (method == "Телефон") "+7 900 000-00-00" else "name@example.com") }
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                notice = if (contact.isBlank()) {
                    "Укажи ${if (method == "Телефон") "номер телефона" else "email"}."
                } else {
                    "Экран подготовлен. Реальная отправка кода появится после подключения SMS/email-провайдера."
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Продолжить")
        }
        if (notice.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(notice, color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Pale)) {
            Column(Modifier.padding(16.dp)) {
                Text("Защита аккаунта", fontWeight = FontWeight.Bold, color = Green)
                Spacer(Modifier.height(5.dp))
                Text(
                    "Планируем вход по одноразовому коду. Пароли хранить не потребуется. Код будет действовать ограниченное время, а частые запросы будут ограничиваться.",
                    color = Ink, fontSize = 12.sp
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "Сейчас это демонстрационный экран: сообщение не отправляется, аккаунт не создаётся и контакт не сохраняется.",
            color = Muted, fontSize = 11.sp
        )
    }
}
