package ru.grocerymaster.app

/**
 * Transport models matching backend API v0.2.
 * Prices are represented as integer minor units in the eventual production API.
 * Do not treat demo UI labels as live offers.
 */
data class ApiCity(
    val id: String,
    val name: String,
    val region: String,
    val country_code: String = "RU"
)

data class ApiStore(
    val id: String,
    val name: String,
    val network: String,
    val city_id: String,
    val address: String? = null
)

data class ApiProduct(
    val id: String,
    val name: String,
    val brand: String? = null,
    val category: String? = null,
    val quantity_value: Double? = null,
    val quantity_unit: String? = null
)

data class ApiPriceOffer(
    val product_id: String,
    val store_id: String,
    val price_rub: Double,
    val currency: String = "RUB",
    val observed_at: String,
    val source: String,
    val is_promo: Boolean = false
)
